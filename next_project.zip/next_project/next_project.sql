-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2019 at 09:16 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `next_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `auth_id` varchar(50) NOT NULL,
  `auth_username` varchar(255) NOT NULL,
  `auth_email` varchar(255) NOT NULL,
  `auth_password` varchar(255) NOT NULL,
  `auth_image` varchar(255) NOT NULL,
  `auth_level` tinyint(2) NOT NULL,
  `auth_date_created` date NOT NULL,
  `auth_is_active` tinyint(2) NOT NULL,
  `auth_default_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`auth_id`, `auth_username`, `auth_email`, `auth_password`, `auth_image`, `auth_level`, `auth_date_created`, `auth_is_active`, `auth_default_password`) VALUES
('users043329', 'adminHLB', 'adminhlb@gmail.com', '$2y$10$WAzwaGuzNeOcMdhIYdVWoeIHjpxMvgEe0iBEtHI1fM0mrkKxYzXXO', 'pgl.png', 2, '2019-12-03', 1, '$2y$10$rMgMh4/KftJ75/cEBkAhWel6uej3lReo3Ir5r2TSfUMj6NjF36m7m'),
('users043624', 'testes', 'testes@gmail.com', '$2y$10$R9cKVPF6JEDQAADpy0dxLe9a7zTsOPYksLenRN.Q6Hjdmn5FIne9m', 'default.jpg', 2, '2019-12-11', 1, '$2y$10$o3oah62KjcRvMjpyc4NMduFx0W3FC4o8me4v8qwvdc3aaPBtcSwC6'),
('users110920', 'Nur Muhammad Syafei', 'nurmuhammadsyafei1447@gmail.com', '$2y$10$4BrBKU9NereZI5ErCNeAOOc1NqZphlu9kCGkajIJDQPjppYjGSi8a', 'aril.jpg', 2, '2019-11-23', 1, '$2y$10$LH4TPc1h5btoruXHIlGMeuviD3VyLf0UPwkg9M5OxXAOe4nS8VZWS');

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `level_id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`level_id`, `nama`) VALUES
(1, 'Pemimpin'),
(2, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `link` varchar(100) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `sort` varchar(20) NOT NULL,
  `access` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `nama`, `link`, `icon`, `sort`, `access`) VALUES
(1, 'User Management', 'administrator/user_management', 'fa-dashboard', '1', 2),
(3, 'Report', 'administrator/report', 'fa-file-text-o', '2', 2),
(4, 'Menu', 'administrator/menu', 'fa-server', '3', 2),
(5, 'Group', 'administrator/grup', 'fa-server', '4', 2),
(7, 'Access Grup', 'administrator/access', 'fa-file-text-o', '5', 2);

-- --------------------------------------------------------

--
-- Table structure for table `menu_access`
--

CREATE TABLE `menu_access` (
  `id_grup` int(11) NOT NULL,
  `id_menu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu_access`
--

INSERT INTO `menu_access` (`id_grup`, `id_menu`) VALUES
(1, 1),
(1, 3),
(1, 4),
(2, 1),
(2, 3),
(2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `menu_grup`
--

CREATE TABLE `menu_grup` (
  `id_grup` int(11) NOT NULL,
  `nama_grup` varchar(50) NOT NULL,
  `desc_grup` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu_grup`
--

INSERT INTO `menu_grup` (`id_grup`, `nama_grup`, `desc_grup`) VALUES
(1, 'Admin', 'Ya Admin'),
(2, 'Kasir', 'Ya buat kasir');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `status_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `status_name`) VALUES
(1, 'Aktif'),
(2, 'Tidak Aktif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`auth_id`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`level_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_grup`
--
ALTER TABLE `menu_grup`
  ADD PRIMARY KEY (`id_grup`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `level_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `menu_grup`
--
ALTER TABLE `menu_grup`
  MODIFY `id_grup` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
