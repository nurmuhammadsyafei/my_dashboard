<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Menu extends MY_Controller		
{
	 
	public function __construct()
	{
		parent::__construct();
		$this->load->library('custom_library');
		if($this->session->userdata('status') != "login"){
			$this->session->set_flashdata('message','<div class="alert alert-danger text-center" role="alert">Anda Harus Login!</div>');
			redirect(base_url('administrator/welcome'));
		}
	}

	public function index()
	{
        $data['menu']=$this->my_model->get_menu();
        
		$this->page('administrator/menu/list',$data);
	}
	
    
}



