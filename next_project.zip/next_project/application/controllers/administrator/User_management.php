<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User_management extends MY_Controller		
{
	 
	public function __construct()
	{
		parent::__construct();
		$this->load->library('custom_library');
		if($this->session->userdata('status') != "login"){
			$this->session->set_flashdata('message','<div class="alert alert-danger text-center" role="alert">Anda Harus Login!</div>');
			redirect(base_url('administrator/welcome'));
		}
	}

	public function index()
	{
        $data['auth']=$this->my_model->get_user();
		$this->page('administrator/user/user_management',$data);
	}
	
    public function myuser($id)
    {
		$this->db->join('level l','l.level_id = auth_user.auth_level' ,'left');
		$this->db->join('status s','s.id = auth_user.auth_is_active' ,'left');
        $data['auth']=$this->db->get_where('auth_user',['auth_id'=>$id])->row_array();
		$this->page('administrator/user/myuser',$data);
    }
    public function e($id)
    {
        $data['auth']=$this->db->get_where('auth_user',['auth_id'=>$id])->row_array();
		$this->page('administrator/user/ed',$data);
    }
    public function go_e()
    {
		$data=[
			'auth_username'	 =>$this->input->post('_username',true),
			'auth_email'	 =>$this->input->post('_email',true),
			'auth_is_active' =>$this->input->post('_status',true),
			'auth_level'	 =>$this->input->post('_level',true)
		];
		$this->db->where('auth_id',$this->input->post('_id',true));
		$this->db->update('auth_user',$data);
		$this->myuser($this->input->post('_id',true));
		// redirect('administrator/user_management/myuser/').$this->input->post('_id',true);
	}
	public function go_edit_2()
    {
		// var_dump($_FILES['_foto']['name']);die();

		if (!empty($_FILES["_foto"]["name"])) {
			$foto = $_FILES['_foto']['name'];
		} else {
			$foto = $this->input->post('_fotolama',true);
		}


		$data=[
			'auth_username'	 => $this->input->post('_username',true),
			'auth_email'	 => $this->input->post('_email',true),
			'auth_is_active' => $this->input->post('_status',true),
			'auth_level'	 => $this->input->post('_level',true),
			'auth_image'	 => $foto
		];
		$this->db->where('auth_id',$this->input->post('_id',true));
		$this->db->update('auth_user',$data);
		$this->_uploadImage();
		// $this->myuser($this->input->post('_id',true));
		redirect('administrator/user_management');
	}
	private function _uploadImage()
	{
		$config['upload_path']          = './image/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['file_name']            = $_FILES["_foto"]["name"];
		$config['overwrite']			= true;
		$config['max_size']             = 1024; // 1MB
		// $config['max_width']            = 1024;
		// $config['max_height']           = 768;

		$this->load->library('upload', $config);

		if ($this->upload->do_upload('_foto')) {
			return $this->upload->data("file_name");
		}
		
		return "default.jpg";
	}
	
	// TAMBAH DATA 
	public function add()
	{
		$this->form_validation->set_rules('_user', 'Name','required|trim');//validasi nama harus ada
		$this->form_validation->set_rules('_email','Email','required|trim|valid_email|is_unique[auth_user.auth_email]',[
			'is_unique'=>'Email ini sudah terdaftar! |  gunakan email lain! ..'
			]); //validasi email harus ada

		$this->form_validation->set_rules('_pass1', 'Password','required|trim|min_length[5]|matches[_pass2]',[
			'matches'=>'Password harus sama!',	
			'min_length'=>'Password terlalu pendek, minimal 5 karakter!'
			]);//validasi nama harus ada
		$this->form_validation->set_rules('_pass2', 'Password','matches[_pass1]');//validasi nama harus ada

		if($this->form_validation->run()==false){	
			$data['kodeadm']=$this->my_model->kodeadmin();
			$this->load->view('administrator/z_header');
			$this->load->view('administrator/user/add_new',$data);
			$this->load->view('administrator/z_footer');
		}else{
			$data=
				[ // untuk memasukkan data ke database
					/*htmlspecialchars() berfungsi untuk filter dari karakter aneh*/
				'auth_id'			=> $this->input->post('_kode',true),
				'auth_username' 	=> htmlspecialchars($this->input->post('_user',true)),
				'auth_email'		=> htmlspecialchars($this->input->post('_email',true)),
				'auth_password' 	=> password_hash($this->input->post('_pass1'),PASSWORD_DEFAULT),
				'auth_image'		=> htmlspecialchars('default.jpg'),
				'auth_level'		=> '2',
				'auth_date_created' => date("Y-m-d"),
				'auth_is_active'	=> '1',
				'auth_default_password'=> password_hash('peiganteng',PASSWORD_DEFAULT)
			];

			$this->db->insert('auth_user',$data);
			$this->session->set_flashdata('message','<span class="hideMe alert alert-success" role="alert">Penambahan Akun Berhasil !</span>');
			redirect('administrator/user_management');
		}
		
	}

	public function get_delete($id)
	{
		$this->db->delete('auth_user',['auth_id'=>$id]);
		$this->session->set_flashdata('message','<span class="hideMe alert alert-success" role="alert">Akun Berhasil Dihapus !</span>');
		redirect('administrator/user_management');
	}



	Public function tes()
	{
		$this->load->view('teshtml');
	}
}



