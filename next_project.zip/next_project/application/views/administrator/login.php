
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?= base_url('assets/bootstrap/bootstrap.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/font-awesome/css/font-awesome.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/Ionicons/ionicons.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/adminlte/adminlte.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/plugins/iCheck/square/blue.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/bower_components/jvectormap/jquery-jvectormap.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/dist/css/skins/_all-skins.min.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/dist/css/AdminLTE.min.css')?>">
</head>


<body class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">
      <a href="#"><b>Sign in </b>Syafei</a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body" style="border-top:5px solid black">
      <p class="login-box-msg">Sign in to start your session</p>

      <?= form_open( base_url('administrator/welcome') ,['method' => 'POST']); ?>
        <div class="form-group has-feedback">
          <?= $this->session->flashdata('message'); ?>
          <input name="_email" type="email" class="form-control" placeholder="Email">
        </div>
        <div class="form-group has-feedback">
          <?= $this->session->flashdata('message_password'); ?>
          <input name="_password" type="password" class="form-control" placeholder="Password">
        </div>
        <div class="row">
          <div class="col-xs-8">
            <div class="checkbox icheck">
              <a href="<?= base_url('administrator/welcome/lupapasword') ?>">Lupa Password ?</a>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-xs-4">
            <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      <?= form_close(); ?>

    </div>
    <!-- /.login-box-body -->
  </div>
  <!-- /.login-box -->


<script src="<?= base_url('assets/bower_components/jquery/dist/jquery.min.js')?>"></script>
<script src="<?= base_url('assets/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
<script src="<?= base_url('assets/bower_components/fastclick/lib/fastclick.js')?>"></script>
<script src="<?= base_url('assets/dist/js/adminlte.min.js')?>"></script>
<script src="<?= base_url('assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js')?>"></script>
<script src="<?= base_url('assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')?>"></script>
<script src="<?= base_url('assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')?>"></script>
<script src="<?= base_url('assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')?>"></script>
<script src="<?= base_url('assets/bower_components/chart.js/Chart.js')?>"></script>
<script src="<?= base_url('assets/dist/js/pages/dashboard2.js')?>"></script>
<script src="<?= base_url('assets/dist/js/demo.js')?>"></script>
  <script src="<?= base_url('assets/jquery/jquery.min.js')?>"></script>
  <script src="<?= base_url('assets/bootstrap/bootstrap.min.js')?>"></script>
  <script src="<?= base_url('assets/icheck/icheck.min.js')?>"></script>
  <script>
    $(function () {
      $('input').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        radioClass: 'iradio_square-blue',
        increaseArea: '20%' /* optional */
      });
    });
  </script>
</body>
</html>
