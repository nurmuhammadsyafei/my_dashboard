<!-- Profile Image -->
<div class="row">
    <div class="col-md-6">
        <div class="box box-primary">
        <div class="box-body box-profile">
            <img class="profile-user-img img-responsive img-circle" src="<?= base_url('image/').$this->session->userdata('data')['auth_image'] ?>" alt="User profile picture">

            <h3 class="profile-username text-center"><?= $auth['auth_username']?></h3>

            <p class="text-muted text-center">Software Engineer</p>

            <ul class="list-group list-group-unbordered">
            <li class="list-group-item">
                <b>Username</b> <span class="pull-right"><?= $auth['auth_username']?></span>
            </li>
            <li class="list-group-item">
                <b>Email</b> <span class="pull-right"><?= $auth['auth_email']?></span>
            </li>
            <li class="list-group-item">
                <b>Level</b> <span class="pull-right"><?= $auth['nama']?></span>
            </li>
            </li>
            <li class="list-group-item">
                <b>Status</b> <span class="pull-right"><?= $auth['status_name']?></span>
            </li>
            </ul>
            <a href="<?= base_url('administrator/user_management/e/').$auth['auth_id']?>" class="btn btn-primary btn-block"><b>Edit Profil</b></a>
        </div>
        <!-- /.box-body -->
        </div>
    </div>
</div>