<!-- Profile Image -->
<div class="row">
    <div class="col-md-6">
        <div class="box box-primary">
        <form action="<?= base_url('administrator/user_management/go_e') ?>" method="POST">
        <div class="box-body box-profile">
        <h3 class="text-center">Edit Profil</h3>
            <ul class="list-group list-group-unbordered">
            <li class="list-group-item">
                <b>Username</b> 
                <input name="_id" type="hidden" value="<?= $auth['auth_id']?>">
                <input name="_username" class="form-control input-sm" type="text" value="<?= $auth['auth_username']?>">
            </li>
            <li class="list-group-item">
                <b>Email</b>
                <input name="_email" class="form-control input-sm" type="email" value="<?= $auth['auth_email']?>">
            </li>
            <li class="list-group-item">
                <b>Level</b> 
                <?php $level = $this->db->query("SELECT * FROM level")->result_array();?>
                  <select class="form-control" name="_level">
                  <option value="">Pilih level</option>
                  <?php foreach($level as $a ){
                      $c=$a['nama'];
                      $id=$a['level_id'];
                      echo "<option value='$id'";
                      echo $auth['auth_level']==$id?'selected="selected"':'';
                      echo ">$c</option>"; 
                  } ?>
                  </select>
            </li>
            </li>
            <li class="list-group-item">
                <b>Status</b>
                <?php $stt = $this->db->query("SELECT * FROM status")->result_array();?>
                <select class="form-control" name="_status">
                    <option value="">Pilih Status</option>
                    <?php foreach($stt as $a ){
                      $c=$a['status_name'];
                      $id=$a['id'];
                      echo "<option value='$id'";
                      echo $auth['auth_is_active']==$id?'selected="selected"':'';
                      echo ">$c</option>"; 
                  } ?>
                </select>
            </li>
            <li class="list-group-item">
            <b>Foto</b>
                <input class="form-control" type="file">
            </li>
            </ul>
            <button type="submit" class="btn btn-primary btn-block"><b>Update</b></button>
            </form>
        </div>
        <!-- /.box-body -->
        </div>
    </div>
</div>