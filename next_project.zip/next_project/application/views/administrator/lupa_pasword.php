
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?= base_url('assets/bootstrap/bootstrap.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/font-awesome/css/font-awesome.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/Ionicons/ionicons.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/adminlte/adminlte.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/plugins/iCheck/square/blue.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/bower_components/jvectormap/jquery-jvectormap.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/dist/css/skins/_all-skins.min.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/dist/css/AdminLTE.min.css')?>">
</head>


<body class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">
      <a href="#">Lupa <b>Password </b></a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body" style="border-top:5px solid black">
      <p class="login-box-msg">Atur Ulang Kata Sandi</p>

      <?= form_open( base_url('administrator/welcome/lupapasword') ,['method' => 'POST']); ?>
        <div class="form-group has-feedback">
          <input name="_email" type="email" class="form-control" placeholder="Email">
          <?= $this->session->flashdata('message')?>
        </div>
        <div class="form-group has-feedback">
            <input name="_pasdef" type="password" class="form-control" placeholder="Password Default">
          <?= $this->session->flashdata('message_password')?>
        </div>
        <div class="row">
          <div class="col-xs-8">
            <div class="checkbox icheck">
                <a href="<?= base_url('administrator/welcome') ?>">kembali </a>
            </div>
          </div>
          <div class="col-xs-4">
            <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
          </div>
        </div>
    <?= form_close(); ?>

    </div>
    <!-- /.login-box-body -->
  </div>
  <!-- /.login-box -->
