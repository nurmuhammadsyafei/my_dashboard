
<div class="row">
    <div class="col-md-7">
        <div class="box box-success">
            <div class="box-header with-border">
                
                <div class="row">
                    <div class="col-md-4">
                        <h3 class="box-title">Access Group <b><?= $grup['nama_grup'] ?></b></h3>
                    </div>
                    <div class="col-md-6" id="mydiv">
                        <?= $this->session->flashdata('message'); ?>
                    </div>
                </div>
                <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                </div>
            </div>
            <div class="box-body no-padding">
                <div class="row">
                <div class="col-md-12 col-sm-9">
                    <form action="<?= base_url('administrator/access/tambah_detail')?>" method="POST">
                    <input type="hidden" name="id" value="<?= $id ?>">
                    <?php $no=1;
                    foreach ($menu as $dt){  ?>
                        <input type="checkbox" name="access<?= $no++ ?>" value="<?= $dt['id']?>"<?php 
                        for ($i=0; $i <= $jmlakses-1; $i++){
                        if($dt['id']==$access[$i]['id_menu']){echo 'checked="checked"';} }?> 
                        
                        ><?= $dt['nama']?><br>
                    <?php }  ?>
                    <button onclick="window.history.go(-1)">back</button>
                    <button type="submit">Simpan</button>
                    </form>
                <div class="col-md-3 col-sm-4">
                </div>
                </div>
            </div>
        </div>
    </div>
</div>