


<form action="<?= base_url('administrator/access/tambah_detail')?>" method="POST">
<?php $no=1;


 //var_dump($access[2]['id_menu']);die();
foreach ($menu as $dt){  ?>

    <input type="checkbox" name="<?= $dt['id']?>" value="<?= $dt['id']?>"<?php 
    for ($i=0; $i <= $jmlakses-1; $i++){
    if($dt['id']==$access[$i]['id_menu']){echo 'checked="checked"';} }?> 
    
    ><?= $dt['id']?><br>
<?php }  ?>
<button type="submit">GO</button>
</form>


