






  <?php 
  /*
   * Variabel $headernya diambil dari libraries template.php
   * (application/libraries/template.php)
   * */
  echo $headernya; ?>

<div id="content">
  <?php 
  /*
   * Variabel $contentnya diambil dari libraries template.php
   * (application/libraries/template.php)
   * */
  echo $contentnya; ?>
</div>


  <?php 
  /*
   * Variabel $footernya diambil dari libraries template.php
   * (application/libraries/template.php)
   * */
  echo $footernya; ?>